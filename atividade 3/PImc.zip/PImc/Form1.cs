﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double Peso, Altura, IMC;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtIMC.Clear();
            mskbxAltura.Clear();
            mskbxPeso.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if(!double.TryParse(mskbxPeso.Text, out Peso))
            {
                MessageBox.Show("Peso inválido");
                mskbxPeso.Focus();
            }
            else if (Peso <= 0)
            {
                MessageBox.Show("Peso inválido");
                mskbxPeso.Focus();
            
            }
            if (!double.TryParse(mskbxAltura.Text, out Altura))
            {
                MessageBox.Show("Altura inválida");
                mskbxAltura.Focus();
            }
            else if (Altura <= 0)
            {
                MessageBox.Show("Altura inválida");
                mskbxAltura.Focus();
            }          
                IMC = Peso/Math.Pow(Altura,2);
                IMC = Math.Round(IMC,1);
                txtIMC.Text = IMC.ToString();

            if (IMC < 18.5){
                MessageBox.Show("Magreza");
            }
            else if(IMC >=18.5 && IMC <= 24.9)
            {
                MessageBox.Show("Normal");
            }
            else if (IMC >= 25 && IMC <= 29.9)
            {
                MessageBox.Show("Sobrepeso");
            }
            else if (IMC >= 30 && IMC <= 39.9)
            {
                MessageBox.Show("Obesidade");
            }
            if (IMC >= 40)
            {
                MessageBox.Show("Obesidade Grave");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

    }
}
