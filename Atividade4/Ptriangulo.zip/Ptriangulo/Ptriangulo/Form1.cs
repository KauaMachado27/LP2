﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double Lado1, Lado2, Lado3;

        private void btnSair_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado1.Text, out Lado1))
            {
                MessageBox.Show("Lado 1 inválido");
                txtLado1.Focus();
            }
            else if (Lado1 <= 0)
            {
                MessageBox.Show("Lado 1 inválido");
                txtLado1.Focus();
            }
            else if (!double.TryParse(txtLado2.Text, out Lado2))
            {
                MessageBox.Show("Lado 2 inválido");
                txtLado2.Focus();
            }
            else if (Lado2 <= 0)
            {
                MessageBox.Show("Lado 2 inválido");
                txtLado2.Focus();
            }
            else if (!double.TryParse(txtLado3.Text, out Lado3))
            {
                MessageBox.Show("Lado 3 inválido");
                txtLado3.Focus();
            }
            else if (Lado3 <= 0)
            {
                MessageBox.Show("Lado 3 inválido");
                txtLado1.Focus();
            }
            else if (!((Math.Abs(Lado1 - Lado2) < Lado3 && Lado3 < Lado1 + Lado2) &&
                (Math.Abs(Lado2 - Lado3) < Lado1 && Lado1 < Lado2 + Lado3) &&
                (Math.Abs(Lado1 - Lado3) < Lado2 && Lado2 < Lado1 + Lado3))){
                MessageBox.Show("O triângulo não existe");
            }
            else if (Lado1==Lado2 && Lado2 ==Lado3)
            {
                txtTriangulo.Text = "Equilátero";
            }
            else if (Lado2 == Lado1 || Lado2==Lado3 || Lado3 == Lado1)
            {
                txtTriangulo.Text = "Isósceles";
            }
            else
            {
                txtTriangulo.Text = "Escaleno";
            }         
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
