﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnGerarAleatorio_Click(object sender, EventArgs e)
        {
            int Numero1, Numero2;
            if (!int.TryParse(txtNumero1.Text, out Numero1) || !int.TryParse(txtNumero1.Text, out Numero2)
               || Numero1 < 0 || Numero2 < 0 || Numero2 < Numero1)
            {
                MessageBox.Show("Número inválido");
                txtNumero1.Focus();
                txtNumero2.Focus();
            }
            else
            {
                Random objAlet = new Random();
                Double sorteado = objAlet.Next(Numero1, Numero2);
                MessageBox.Show("O número sorteado=" + sorteado);
            }
        }
    }
}
