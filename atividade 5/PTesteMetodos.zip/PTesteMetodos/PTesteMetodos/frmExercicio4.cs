﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int tamanho = rchtxtFrase.TextLength;
            int contaNum = 0;
            int i = 0;
            while (i < tamanho)
            {
                if (Char.IsNumber(rchtxtFrase.Text[i]))
                {
                    contaNum ++;


                }
                i++;
            }
            MessageBox.Show($"Quantidade de números: {contaNum}");
        }

        private void btnPrimeiroVazio_Click(object sender, EventArgs e)
        {
            int posicao = -1;
            for (var i = 0; i < rchtxtFrase.Text[i]; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i;
                    break;
                }

            }
            MessageBox.Show($"Posição 1° caracter branco: {posicao}");
        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            int tamanho = rchtxtFrase.TextLength;
            int contaLetra = 0;
            int i = 0;
            while (i < tamanho)
            {
                if (Char.IsLetter(rchtxtFrase.Text[i]))
                {
                    contaLetra++;


                }
                i++;
            }
            MessageBox.Show($"Quantidade de letras: {contaLetra}");
        }
    }
}
