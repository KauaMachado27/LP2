﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetinho2
{
    public partial class Form1 : Form
    {
        double raio, altura, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAltura_Validating(object sender, CancelEventArgs e)
        {
            if(!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida");
                e.Cancel = true;
            }
            else if (altura <= 0)
            {
                MessageBox.Show("A altura deve ser maior que zero");
                e.Cancel = true;
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            resultado = Math.PI * Math.Pow(raio, 2) * altura;
            txtResultado.Text = resultado.ToString("N2");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = "";
            txtResultado.Text = "";

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text,out raio))
            {
                MessageBox.Show("Raio inválido!");
                txtRaio.Focus();
            }
            else if (raio <=0)
            {
                MessageBox.Show("raio deve ser maior que zero");
                txtRaio.Focus();
            }
        }
    }
}
