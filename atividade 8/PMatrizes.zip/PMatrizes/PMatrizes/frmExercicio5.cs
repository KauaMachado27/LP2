﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }



        private void btnVerificar_Click(object sender, EventArgs e)
        {
            char[] gabarito = new char[10];
            gabarito[0] = 'B';
            gabarito[1] = 'C';
            gabarito[2] = 'A';
            gabarito[3] = 'C';
            gabarito[4] = 'D';
            gabarito[5] = 'E';
            gabarito[6] = 'A';
            gabarito[7] = 'D';
            gabarito[8] = 'E';
            gabarito[9] = 'E';
            string comp;

            char[,] respostaAlunos = new char[5, 10];
            string auxiliar = "";

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j + 1}º resposta do aluno{i + 1}",
                     "Entrada de dados");
                    if (!char.TryParse(auxiliar, out respostaAlunos[i, j]) 
                        || (respostaAlunos[i,j] != 'A' && respostaAlunos[i, j] != 'B'
                        && respostaAlunos[i, j] != 'C' && respostaAlunos[i, j] != 'D'
                        && respostaAlunos[i, j] != 'E'))
                    {
                        MessageBox.Show($"Resposta inválida");
                        j--;
                    }
                    else
                    {
                        if (respostaAlunos[i, j] == gabarito[j])
                        {
                            comp = "acertou";
                        }
                        else
                        {
                            comp = "errou";
                        }
                        lstboxResposta.Items.Add($"O Aluno{i + 1} {comp} a questão {j + 1}: era {gabarito[j]} e escolheu {respostaAlunos[i, j]}");
                    }

                }
            }
        }
    }
}
