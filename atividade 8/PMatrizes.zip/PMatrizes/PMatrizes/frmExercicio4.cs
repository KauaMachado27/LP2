﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            string[] vetor = new string[10];

            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o nome da {i + 1}º pessoa ",
                    "Entrada de dados");
                vetor[i] = auxiliar;

                int caracteres = auxiliar.Length;

                for (int j = 0; j < auxiliar.Length; j++)
                {
                    if (Char.IsWhiteSpace(auxiliar[j]))
                    {
                        caracteres--;
                    }
                        
                }
                lstboxNome.Items.Add($"O nome: {vetor[i]} tem {caracteres} caracteres");
                auxiliar = "";

                }
            }
        }
    }
