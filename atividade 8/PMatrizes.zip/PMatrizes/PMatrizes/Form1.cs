﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Forms já existe");
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 obj4 = new frmExercicio4();
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }

        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0;  i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}º número ",
                    "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show($"Número inválido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach(int x in vetor)
            {
                auxiliar += x + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Forms já existe");
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 obj5 = new frmExercicio5();
                obj5.WindowState = FormWindowState.Maximized;
                obj5.Show();
            }
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList minhaLista = new ArrayList() {"Ana", "André", "Débora","Fátima",
            "João", "Janete", "Otávio", "Marcelo", "Pedro"};
            minhaLista.Remove("Otávio");
            string auxiliar = "";
            foreach(string nomes in minhaLista)
            {
                auxiliar += nomes + "\n";
            }
            MessageBox.Show(auxiliar);  

        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double media = 0;
            double[,] notas = new double[20,3];
            string auxiliar = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j + 1}º nota do aluno{i + 1}",
                     "Entrada de dados");

                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show($"Número inválido");
                        j--;
                    }
                    media += notas[i,j];
                }
                media = media / 3;
                MessageBox.Show($"A média do aluno {i + 1} é: {media}");
                media = 0;
            }
        }
    }
}
